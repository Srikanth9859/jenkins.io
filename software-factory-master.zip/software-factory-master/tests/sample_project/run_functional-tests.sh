#!/bin/bash

set -x

nosetests -v tests
